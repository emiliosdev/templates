import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feeds-widget4',
  templateUrl: './feeds-widget4.component.html',
})
export class FeedsWidget4Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
