import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extended',
  templateUrl: './extended.component.html',
  styleUrls: ['./extended.component.scss'],
})
export class ExtendedComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
