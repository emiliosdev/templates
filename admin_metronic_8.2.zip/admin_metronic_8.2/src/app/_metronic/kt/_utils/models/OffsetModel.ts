export interface OffsetModel {
  top: number
  left: number
}
