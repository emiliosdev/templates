# Metronic | Bootstrap HTML, VueJS, React, Angular, Asp.Net Core, Rails, Spring, Blazor, Django, Flask & Laravel Admin Dashboard Theme

- Demos can be downloaded online from [Metronic Downloads](https://devs.keenthemes.com/metronic)

- For a quick start please check [Online documentation](https://preview.keenthemes.com/html/metronic/docs/)

- For any theme related questions go to our [Support Center](https://devs.keenthemes.com)

- Using Metronic in a new project or for a new client ? Purchase a new license from [Themeforest Marketplace](https://1.envato.market/EA4JP)
  or watch [Youtube Video](https://youtu.be/HJ3RNhoI24A) to find out more information about licenses.

- Get Metronic v5, Metronic v6 or Metronic v7 download links by providing your purchase code via [Support Center](https://devs.keenthemes.com)

- amCharts 15% Discount Code For Keenthemes Users
  You can download and use all amCharts products for free. The only limitation of the free version is that a small link to this web site will be
  displayed in the top left corner of your charts. If you would like to use charts without this link, or you appreciate the software and would
  like to support its creators, please purchase a commercial license. Keenthemes users can exclusively use "keenthemes" promo
  code(without quotes, case insensitive) for 15% DISCOUNT for commercial license of amCharts. For more info please check [amCharts Site](https://www.amcharts.com/)

- Stay tuned for updates via [Twitter](https://twitter.com/keenthemes) and [Instagram](https://instagram.com/keenthemes) and
  check our marketplace for more amazing products: [Keenthemes Marketplace](https://keenthemes.com)

Happy coding with Metronic!