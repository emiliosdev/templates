// Fullscreen Lightbox - stylish lightbox without jQuery!: https://fslightbox.com/javascript/documentation/installation#package-manager
require('fslightbox');