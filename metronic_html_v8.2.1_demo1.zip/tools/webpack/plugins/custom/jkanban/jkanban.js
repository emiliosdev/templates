// jKanban Board - Vanilla Javascript plugin for manage kanban boards: https://github.com/riktar/jkanban

require('jkanban/dist/jkanban.js');

require('./jkanban.scss');
